﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace High_Low_Game
{
    class Program
    {
        static void Main(string[] args)
        {
            //Welcome Message
            Console.WriteLine("Welcome to the High-Low Game!!!!!");

            //Creates a new random number generator
            Random rng = new Random();
            int number = rng.Next(1, 50);

            //Guesses counter
            int guesses = 0;

            //While Loop
            while (true)
            { 

                //User enters guess
                Console.Write("Enter A Guess : ");
                int guess = Convert.ToInt32(Console.ReadLine());
                guesses = guesses + 1;

                //Compare Guess to Number
                if (guess < number)
                {
                    Console.WriteLine("Too low..... Try Again : ");
                    
                }

                else if (guess > number)
                {
                    Console.WriteLine("Too high..... Try Again : ");
                    
                }

                else
                {
                    Console.WriteLine("Congratulations, you've guessed the number correctly : ");
                    Console.WriteLine("You took",guesses,"guesses to guess the number: ");
                    Console.WriteLine("Would you like to try again : yes or no ");
                    string answer = Console.ReadLine();
                 

                }
            }
                //Wait for key press
                Console.ReadKey();

            
        }
    }
}
